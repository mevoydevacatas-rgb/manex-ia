package com.manex.ia

import android.content.ContentResolver
import android.net.Uri
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/** Añade texto al FINAL de un .docx sin tocar nada de lo que ya contiene. */
object DocxAppender {

    fun append(cr: ContentResolver, uri: Uri, stamp: String, text: String) {
        val original = cr.openInputStream(uri)?.use { it.readBytes() } ?: ByteArray(0)
        val newParagraphs = paragraphs(stamp, text)
        // Se construye todo en memoria primero: si algo falla, el archivo original no se toca.
        val result = if (original.isEmpty()) newDocx(newParagraphs) else modify(original, newParagraphs)
        cr.openOutputStream(uri, "wt")!!.use { it.write(result) }
    }

    private fun modify(original: ByteArray, add: String): ByteArray {
        val out = ByteArrayOutputStream()
        var found = false
        ZipInputStream(ByteArrayInputStream(original)).use { zin ->
            ZipOutputStream(out).use { zout ->
                while (true) {
                    val e = zin.nextEntry ?: break
                    val data = zin.readBytes()
                    zout.putNextEntry(ZipEntry(e.name))
                    if (e.name == "word/document.xml") {
                        found = true
                        zout.write(insert(String(data, Charsets.UTF_8), add).toByteArray(Charsets.UTF_8))
                    } else {
                        zout.write(data)
                    }
                    zout.closeEntry()
                }
            }
        }
        if (!found) throw IllegalStateException("El archivo no es un Word (.docx) válido")
        return out.toByteArray()
    }

    private fun insert(xml: String, add: String): String {
        val bodyEnd = xml.lastIndexOf("</w:body>")
        if (bodyEnd < 0) throw IllegalStateException("Word con formato no reconocido")
        val sect = xml.lastIndexOf("<w:sectPr", bodyEnd)
        val at = if (sect >= 0 && !xml.substring(sect, bodyEnd).contains("</w:p>")) sect else bodyEnd
        return xml.substring(0, at) + add + xml.substring(at)
    }

    private fun paragraphs(stamp: String, text: String) = buildString {
        append(p("", false))
        append(p(stamp, true))
        clean(text).lines().forEach { append(p(it, false)) }
    }

    private fun clean(s: String) =
        s.replace("\r", "").replace(Regex("[\\x00-\\x08\\x0B\\x0C\\x0E-\\x1F]"), "")

    private fun esc(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")

    private fun p(text: String, bold: Boolean): String {
        val rpr = if (bold) "<w:rPr><w:b/></w:rPr>" else ""
        return "<w:p><w:r>$rpr<w:t xml:space=\"preserve\">${esc(text)}</w:t></w:r></w:p>"
    }

    private fun newDocx(body: String): ByteArray {
        val out = ByteArrayOutputStream()
        ZipOutputStream(out).use { z ->
            fun put(name: String, content: String) {
                z.putNextEntry(ZipEntry(name)); z.write(content.toByteArray(Charsets.UTF_8)); z.closeEntry()
            }
            put("[Content_Types].xml",
                """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/></Types>""")
            put("_rels/.rels",
                """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/></Relationships>""")
            put("word/document.xml",
                """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body>$body</w:body></w:document>""")
        }
        return out.toByteArray()
    }
}
