package com.manex.ia

import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

class MainActivity : ComponentActivity() {

    private val executor = Executors.newSingleThreadExecutor()
    private val prefs by lazy { getSharedPreferences("manex", MODE_PRIVATE) }
    private lateinit var status: TextView

    private val openDoc =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { saveDoc(it) }
    private val createDoc =
        registerForActivityResult(ActivityResultContracts.CreateDocument(DOCX_MIME)) { saveDoc(it) }
    private val pickFile =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
            r.data?.data?.let { process(it) }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (24 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(pad, pad, pad, pad)
            setBackgroundColor(Color.WHITE)
        }
        root.addView(TextView(this).apply {
            text = "MANEX IA"
            textSize = 32f
            gravity = Gravity.CENTER
            setTextColor(Color.BLACK)
        })
        root.addView(Button(this).apply {
            text = "PDF & JPG"
            textSize = 22f
            setOnClickListener { onButton() }
        }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = pad })
        status = TextView(this).apply {
            textSize = 16f
            gravity = Gravity.CENTER
            setTextColor(Color.DKGRAY)
        }
        root.addView(status, LinearLayout.LayoutParams(-1, -2).apply { topMargin = pad })
        setContentView(root)
    }

    private fun onButton() {
        if (prefs.getString("doc", null) == null) askDoc() else openExplorer()
    }

    // Solo la primera vez: elegir (o crear) el Word "Biblioteca IA MANEX"
    private fun askDoc() {
        AlertDialog.Builder(this)
            .setTitle("Archivo Word")
            .setItems(arrayOf("Ya tengo \"Biblioteca IA MANEX\"", "Crear \"Biblioteca IA MANEX.docx\"")) { _, w ->
                if (w == 0) openDoc.launch(arrayOf(DOCX_MIME))
                else createDoc.launch("Biblioteca IA MANEX.docx")
            }.show()
    }

    private fun saveDoc(uri: Uri?) {
        if (uri == null) return
        contentResolver.takePersistableUriPermission(
            uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
        )
        prefs.edit().putString("doc", uri.toString()).apply()
        openExplorer()
    }

    // Abre "ES Explorador de archivos"; si no está, usa el selector normal
    private fun openExplorer() {
        val base = Intent(Intent.ACTION_GET_CONTENT).apply {
            type = "*/*"
            addCategory(Intent.CATEGORY_OPENABLE)
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("image/jpeg", "application/pdf"))
        }
        try {
            pickFile.launch(Intent(base).setPackage(ES_PKG))
        } catch (e: ActivityNotFoundException) {
            pickFile.launch(base)
        }
    }

    private fun process(uri: Uri) {
        val docUri = Uri.parse(prefs.getString("doc", null) ?: return)
        say("Procesando…")
        executor.execute {
            try {
                val name = displayName(uri).lowercase()
                val type = contentResolver.getType(uri)?.lowercase() ?: ""
                val text = when {
                    type == "application/pdf" || name.endsWith(".pdf") -> pdfText(uri)
                    type == "image/jpeg" || name.endsWith(".jpg") || name.endsWith(".jpeg") ->
                        ocr(InputImage.fromFilePath(this, uri))
                    else -> throw IllegalArgumentException(
                        "Tipo de archivo no válido. Solo se admiten archivos PDF o JPG."
                    )
                }
                if (text.isBlank()) throw IllegalStateException("No he encontrado texto en el archivo")
                val stamp = SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale("es", "ES")).format(Date())
                DocxAppender.append(contentResolver, docUri, stamp, text)
                say("✔ Añadido a Biblioteca IA MANEX\n$stamp")
            } catch (e: Exception) {
                say("Error: ${e.message}", true)
            }
        }
    }

    private fun say(msg: String, error: Boolean = false) = runOnUiThread {
        status.setTextColor(if (error) Color.RED else Color.DKGRAY)
        status.text = msg
    }

    private fun displayName(uri: Uri): String {
        contentResolver.query(uri, null, null, null, null)?.use { c ->
            val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (i >= 0 && c.moveToFirst()) return c.getString(i) ?: ""
        }
        return uri.lastPathSegment ?: ""
    }

    private fun ocr(image: InputImage): String {
        val rec = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        try {
            return Tasks.await(rec.process(image)).text
        } finally {
            rec.close()
        }
    }

    private fun pdfText(uri: Uri): String {
        PDFBoxResourceLoader.init(applicationContext)
        val t = contentResolver.openInputStream(uri)!!.use { s ->
            PDDocument.load(s).use { PDFTextStripper().getText(it) }
        }
        return if (t.isNotBlank()) t else pdfOcr(uri) // PDF escaneado → OCR
    }

    private fun pdfOcr(uri: Uri): String {
        val sb = StringBuilder()
        contentResolver.openFileDescriptor(uri, "r")!!.use { fd ->
            PdfRenderer(fd).use { r ->
                for (i in 0 until r.pageCount) {
                    r.openPage(i).use { page ->
                        val w = 1600
                        val h = w * page.height / page.width
                        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                        bmp.eraseColor(Color.WHITE)
                        page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                        sb.append(ocr(InputImage.fromBitmap(bmp, 0))).append("\n")
                    }
                }
            }
        }
        return sb.toString()
    }

    companion object {
        const val ES_PKG = "com.estrongs.android.pop"
        const val DOCX_MIME =
            "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
    }
}
