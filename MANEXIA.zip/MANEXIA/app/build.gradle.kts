plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.manex.ia"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.manex.ia"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-ktx:1.9.1")
    // OCR para JPG (funciona sin internet)
    implementation("com.google.mlkit:text-recognition:16.0.1")
    // Texto de PDF
    implementation("com.tom-roush:pdfbox-android:2.0.27.0")
}
